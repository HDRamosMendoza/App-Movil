package com.example.api_mef;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.location.LocationCallback;

public class MainActivity extends AppCompatActivity {

    private TextView txtUbicacion;
    private LocationCallback trackingCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        txtUbicacion = findViewById(R.id.txtUbicacion);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        iniciarTracking();
    }

    private void iniciarTracking() {

        if (!SetTimeHelper.hasLocationPermissions(this)) {
            SetTimeHelper.requestLocationPermissions(this);
            return;
        }

        /* Iniciar tracking cada 10 segundos */
        trackingCallback = SetTimeHelper.startTrackingEvery10Seconds(
                this,
                true,
                new SetTimeHelper.LocationCallbackResult() {
                    @Override
                    public void onSuccess(@NonNull SetTimeHelper.Wgs84Location result) {

                        String texto =
                                "Latitud: " + result.lat + "\n" +
                                        "Longitud: " + result.lon + "\n" +
                                        "Precisión: " + result.accuracyMeters + " m\n" +
                                        "Proveedor: " + result.provider;

                        txtUbicacion.setText(texto);
                    }

                    @Override
                    public void onError(@NonNull String message) {
                        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (trackingCallback != null) {
            SetTimeHelper.stopTracking(this, trackingCallback);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SetTimeHelper.REQ_LOCATION_PERMS) {
            iniciarTracking();
        }
    }
}
package com.example.api_mef;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Looper;
import android.provider.Settings;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

import java.util.Locale;

/* Helper para geolocalización */
public class SetTimeHelper {

    public static final int REQ_LOCATION_PERMS = 7001;

    public interface LocationCallbackResult {
        void onSuccess(@NonNull Wgs84Location result);
        void onError(@NonNull String message);
    }

    public static class Wgs84Location {
        public final double lat;
        public final double lon;
        public final float accuracyMeters;
        public final long timeMillis;
        public final String provider;

        public Wgs84Location(double lat, double lon, float accuracyMeters, long timeMillis, String provider) {
            this.lat = lat;
            this.lon = lon;
            this.accuracyMeters = accuracyMeters;
            this.timeMillis = timeMillis;
            this.provider = provider;
        }

        public String toText() {
            return String.format(Locale.US, "lat=%.7f, lon=%.7f, acc=%.1fm, provider=%s",
                    lat, lon, accuracyMeters, provider);
        }
    }

    /* Verifica permisos (FINE/COARSE) */
    public static boolean hasLocationPermissions(@NonNull Context ctx) {
        boolean fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
        boolean coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
        return fine || coarse;
    }

    /* Solicita permisos */
    public static void requestLocationPermissions(@NonNull Activity act) {
        ActivityCompat.requestPermissions(
                act,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                REQ_LOCATION_PERMS
        );
    }

    /* Valida si el servicio de ubicación está activo (Location Services) */
    public static boolean isLocationServiceEnabled(@NonNull Context ctx) {
        LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return lm.isLocationEnabled();
        } else {
            boolean gps = false, net = false;
            try { gps = lm.isProviderEnabled(LocationManager.GPS_PROVIDER); } catch (Exception ignored) {}
            try { net = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER); } catch (Exception ignored) {}
            return gps || net;
        }
    }

    /* Valida si el GPS provider está habilitado (alta precisión) */
    public static boolean isGpsProviderEnabled(@NonNull Context ctx) {
        LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return false;
        try {
            return lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception e) {
            return false;
        }
    }

    /* Abre ajustes de ubicación */
    public static void openLocationSettings(@NonNull Activity act) {
        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        act.startActivity(intent);
    }

    /* Obtiene ubicación */
    public static void getUbicationWGS84Geografic(
            @NonNull Activity activity,
            boolean highAccuracy,
            @NonNull LocationCallbackResult callback
    ) {
        /* Permisos */
        if (!hasLocationPermissions(activity)) {
            callback.onError("Permisos de ubicación no otorgados. Solicita ACCESS_FINE_LOCATION/COARSE_LOCATION.");
            return;
        }

        /* Servicio ubicación */
        if (!isLocationServiceEnabled(activity)) {
            callback.onError("Servicio de ubicación desactivado. Actívalo en Ajustes.");
            return;
        }

        /* Alta precisión (GPS provider) */
        if (highAccuracy && !isGpsProviderEnabled(activity)) {
            callback.onError("GPS desactivado. Activa 'Ubicación' y modo de alta precisión (GPS).");
            return;
        }

        FusedLocationProviderClient client = LocationServices.getFusedLocationProviderClient(activity);

        try {
            client.getLastLocation()
                    .addOnSuccessListener(activity, loc -> {
                        if (loc != null) {
                            callback.onSuccess(toWgs84(loc));
                        } else {
                            requestSingleUpdate(activity, client, highAccuracy, callback);
                        }
                    })
                    .addOnFailureListener(activity, e ->
                            callback.onError("Error al obtener lastLocation: " + e.getMessage())
                    );
        } catch (SecurityException se) {
            callback.onError("Sin permisos de ubicación: " + se.getMessage());
        } catch (Exception e) {
            callback.onError("Error inesperado al obtener ubicación: " + e.getMessage());
        }
    }

    /* Lectura de ubicación */
    private static void requestSingleUpdate(
            @NonNull Activity activity,
            @NonNull FusedLocationProviderClient client,
            boolean highAccuracy,
            @NonNull LocationCallbackResult callback
    ) {
        int priority = highAccuracy
                ? Priority.PRIORITY_HIGH_ACCURACY
                : Priority.PRIORITY_BALANCED_POWER_ACCURACY;

        LocationRequest request = new LocationRequest.Builder(priority, 3000) // 3s
                .setMinUpdateIntervalMillis(1500)
                .setMaxUpdateDelayMillis(3000)
                .setWaitForAccurateLocation(false)
                .setMaxUpdates(1)
                .build();

        LocationCallback cb = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                client.removeLocationUpdates(this);
                Location loc = locationResult.getLastLocation();
                if (loc == null) {
                    callback.onError("No se pudo obtener ubicación. Intenta en un lugar abierto.");
                    return;
                }
                callback.onSuccess(toWgs84(loc));
            }

            @Override
            public void onLocationAvailability(@NonNull LocationAvailability availability) {
                /* Si no hay senal. Tener en cuenta. Oscar no solicito este punto */
            }
        };

        try {
            client.requestLocationUpdates(request, cb, Looper.getMainLooper());
        } catch (SecurityException se) {
            callback.onError("Sin permisos de ubicación: " + se.getMessage());
        } catch (Exception e) {
            callback.onError("Error al solicitar ubicación: " + e.getMessage());
        }
    }

    private static Wgs84Location toWgs84(@NonNull Location loc) {
        String provider = (loc.getProvider() != null) ? loc.getProvider() : "fused";
        return new Wgs84Location(
                loc.getLatitude(),
                loc.getLongitude(),
                loc.hasAccuracy() ? loc.getAccuracy() : -1f,
                loc.getTime(),
                provider
        );
    }

    /* Android 12+ */
    public static boolean hasPreciseLocation(@NonNull Context ctx) {
        return ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    /* Tracking cada 10 segundos */
    public static LocationCallback startTrackingEvery10Seconds(
            @NonNull Activity activity,
            boolean highAccuracy,
            @NonNull LocationCallbackResult callback
    ) {
        /* Validaciones */
        if (!hasLocationPermissions(activity)) {
            callback.onError("Permisos de ubicación no otorgados.");
            return null;
        }

        if (!isLocationServiceEnabled(activity)) {
            callback.onError("Servicio de ubicación desactivado.");
            return null;
        }

        if (highAccuracy && !isGpsProviderEnabled(activity)) {
            callback.onError("GPS desactivado. Activa el GPS para alta precisión.");
            return null;
        }

        FusedLocationProviderClient client = LocationServices.getFusedLocationProviderClient(activity);

        int priority = highAccuracy
                ? Priority.PRIORITY_HIGH_ACCURACY
                : Priority.PRIORITY_BALANCED_POWER_ACCURACY;

        LocationRequest request = new LocationRequest.Builder(priority, 10_000)
                .setMinUpdateIntervalMillis(10_000)
                .setMaxUpdateDelayMillis(10_000)
                .setMinUpdateDistanceMeters(5)
                .setWaitForAccurateLocation(false)
                .build();

        LocationCallback locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                Location loc = locationResult.getLastLocation();
                if (loc != null) {
                    callback.onSuccess(toWgs84(loc));
                } else {
                    callback.onError("Ubicación null. Esperando señal...");
                }
            }

            @Override
            public void onLocationAvailability(@NonNull LocationAvailability availability) {

            }
        };

        try {
            client.requestLocationUpdates(request, locationCallback, Looper.getMainLooper());
        } catch (SecurityException se) {
            callback.onError("Sin permisos de ubicación: " + se.getMessage());
            return null;
        } catch (Exception e) {
            callback.onError("Error al iniciar tracking: " + e.getMessage());
            return null;
        }

        return locationCallback;
    }

    /* Detiene */
    public static void stopTracking(
            @NonNull Activity activity,
            @NonNull LocationCallback trackingCallback
    ) {
        FusedLocationProviderClient client = LocationServices.getFusedLocationProviderClient(activity);
        client.removeLocationUpdates(trackingCallback);
    }
}
